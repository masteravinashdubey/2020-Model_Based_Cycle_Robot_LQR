# Tech report LaTeX template

A simple tech report template, based on MIT's *AI Memo 519a* by Richard Stallman, back from 1981.
It was the second (I think) take on the Emacs paper, which later appeared on ACM's Conference on Text Processing.

Ironically, this template was written in VS Code... however it uses a GPL License, and hence  is free to use, modify and sell as long as the license is kept the same.
More information can be found on the [LICENSE](LICENSE.txt) file.